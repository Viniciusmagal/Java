/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vetores;

import java.util.Scanner;

/**
 *
 * @author lucav
 */
public class Vetores {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int n;
        System.out.print("quantos números você vai digitar?");
        int N = sc.nextInt();
        double[] vet = new double[N];
        sc.close();
        for(int i = 0; i < N; i++);
        
    }
}
