/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.entrada_de_dados;

import java.util.Scanner;
import java.util.locale;


/**
 *
 * @author lucav
 */
public class Entrada_de_dados {

    public static void main(String[] args) {
String nome1, nome2;
double salario1, salario2;
int idade;
char sexo;
    System.out.print("Digite o nome da primeira pessoa: ");
    
    }
}
