/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finanças;

/**
 *
 * @author Aluno
 */
public class Finanças {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here arruda s
         Tela1 ex = new Tela1();
        ex.setVisible(true);
    }
    
}
